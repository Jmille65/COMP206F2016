char* decrypt(int, char*);
